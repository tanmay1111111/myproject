# Diabetes-Prediction-Project
Machine Learning Web App Built Using Flask Deployed on Heroku

<img src="https://images.everydayhealth.com/images/diabetes-awareness-month-1440x810.jpg">

• This repository consists of files required to deploy a Machine Learning Web App created with Flask and deployed using Heroku platform.

• If you want to view the deployed model, click on the following link:

https://diabetes-projects.herokuapp.com/

• Please do ⭐ the repository, if you like this.😊
